import os
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Get the latest results directory
results_dir = "experiment_results"
run_dirs = [os.path.join(results_dir, d) for d in os.listdir(results_dir) if d.startswith("run_")]
latest_run = max(run_dirs, key=os.path.getmtime)

print(f"Analyzing results from: {latest_run}")

# Read the summary file
summary_file = os.path.join(latest_run, "summary.csv")
summary = pd.read_csv(summary_file)

# Calculate success rate
success_rate = summary["Success"].mean() * 100
print(f"Overall success rate: {success_rate:.1f}%")

# Print summary statistics
print("\nSummary Statistics:")
print(summary[["Experiment", "Success", "Iterations", "PlanLength", "SearchTime"]])

# Plot iterations comparison
plt.figure(figsize=(10, 6))
sns.barplot(x="Experiment", y="Iterations", data=summary, hue="Success")
plt.title("Number of Iterations by Experiment")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig(os.path.join(latest_run, "iterations_comparison.png"))

# Plot search time comparison
plt.figure(figsize=(10, 6))
sns.barplot(x="Experiment", y="SearchTime", data=summary, hue="Success")
plt.title("Search Time by Experiment")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig(os.path.join(latest_run, "search_time_comparison.png"))

# Plot plan length (only for successful experiments)
successful = summary[summary["Success"] == True]
if not successful.empty:
    plt.figure(figsize=(10, 6))
    sns.barplot(x="Experiment", y="PlanLength", data=successful)
    plt.title("Plan Length by Experiment (Successful Only)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(os.path.join(latest_run, "plan_length_comparison.png"))

# Create detailed analysis report
report_file = os.path.join(latest_run, "analysis_report.txt")
with open(report_file, "w") as f:
    f.write("Beluga Solver Experiment Analysis\n")
    f.write("===============================\n\n")
    
    f.write(f"Experiment run: {os.path.basename(latest_run)}\n\n")
    
    f.write(f"Overall success rate: {success_rate:.1f}%\n\n")
    
    f.write("Summary Statistics:\n")
    f.write(summary[["Experiment", "Success", "Iterations", "PlanLength", "SearchTime"]].to_string(index=False))
    f.write("\n\n")
    
    # Compare heuristics
    f.write("Heuristic Comparison:\n")
    heuristic_comparison = summary.groupby("Heuristic").agg({
        "Success": "mean",
        "Iterations": "mean",
        "SearchTime": "mean",
        "PlanLength": lambda x: x[x > 0].mean() if any(x > 0) else 0
    })
    f.write(heuristic_comparison.to_string())
    f.write("\n\n")
    
    # Compare action prioritization
    f.write("Action Prioritization Comparison:\n")
    prioritize_comparison = summary.groupby("Prioritize").agg({
        "Success": "mean",
        "Iterations": "mean",
        "SearchTime": "mean",
        "PlanLength": lambda x: x[x > 0].mean() if any(x > 0) else 0
    })
    f.write(prioritize_comparison.to_string())
    f.write("\n\n")
    
    # Detailed analysis for each experiment
    f.write("Detailed Experiment Analysis:\n")
    for exp_name in summary["Experiment"]:
        exp_dir = os.path.join(latest_run, exp_name.replace(" ", "_"))
        metadata_file = os.path.join(exp_dir, "metadata.json")
        
        if os.path.exists(metadata_file):
            with open(metadata_file, "r") as mf:
                metadata = json.load(mf)
            
            f.write(f"\n{exp_name}:\n")
            f.write(f"  Heuristic: {metadata['heuristic']}\n")
            f.write(f"  Prioritize Actions: {metadata['prioritize_actions']}\n")
            f.write(f"  Success: {metadata['success']}\n")
            f.write(f"  Iterations: {metadata['iterations']}\n")
            f.write(f"  Search Time: {metadata['search_time']:.2f} seconds\n")
            f.write(f"  Total Time: {metadata['total_time']:.2f} seconds\n")
            
            if metadata['success']:
                f.write(f"  Plan Length: {metadata['plan_length']}\n")
            else:
                f.write("  No plan found\n")

print(f"Analysis report saved to: {report_file}")