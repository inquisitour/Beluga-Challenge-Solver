# Beluga Challenge Solver

This is an A* search-based solver for the Beluga Challenge from the TUPLES project.

## Overview

The Beluga Challenge involves managing aircraft parts on jigs, which need to be moved between the Beluga aircraft, racks, and production lines according to various constraints.

This solver uses the A* search algorithm with multiple heuristic options to find optimal plans for Beluga Challenge instances.

## Files

- `beluga_loader.py`: Functions for loading and parsing instance data
- `beluga_state.py`: State representation and transition functions
- `beluga_actions.py`: Action classes and definitions
- `beluga_heuristic.py`: Heuristic functions for A* search
- `beluga_astar.py`: A* search implementation
- `beluga_goal.py`: Goal testing functions
- `beluga_utils.py`: Utility functions for visualization
- `beluga_verification.py`: Plan verification functions
- `beluga_debug.py`: Debugging tools
- `test_astar.py`: Test script for A* search
- `run_beluga_solver.py`: Main solver script

## Usage

To run the solver on an instance file:

```bash
python run_beluga_solver.py <instance_file> [options]
```

## Options

```bash
--max-iterations: Maximum iterations for A* search (default: 10000)
--time-limit: Time limit in seconds (default: 60)
--debug: Run in debug mode for analysis
--output: Output file to save the plan
--heuristic: Heuristic variant to use (standard, weighted, production_focus)
```

## Example

```bash
python run_beluga_solver.py problem_4_s46_j23_r2_oc51_f6.json --max-iterations 15000 --heuristic weighted
```

## Heuristic Variants

Standard: Baseline heuristic with equal weighting of components
Weighted: Prioritizes production requirements over flight processing
Production Focus: Strongly prioritizes completing the production schedule in the correct order

## Experiment Results
For benchmark results comparing different heuristic variants, see the accompanying PDF document.